

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>SRDC</title>

        <link rel="stylesheet" href="../css/homepagestyle.css">
        <link rel="preconnect" href="https://fonts.bunny.net">
        <style>
        body {
    font-family: sans-serif;
    margin: 0;
    padding: 0;
    background-color: #fff;
}

header {
    background-color: white;
    color: #fff;
}

.container {
    max-width: 1000px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    text-align: center;
}
.container-nav {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #092044;
}
.container-header{
    width: 100%;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    width: 200px;
    height: auto;
    margin: 15px;
}

.search-bar {
    margin-left: auto;
    text-align: right;
    border: 2px solid #ccc;
    border-radius: 5px;
}

input[type="text"] {
    padding: 10px;
    width: 80%;
    border: none;
    border-radius: 5px;
}

nav {
    margin-left: 20%;
    margin-right: 20%;
    margin-bottom: 20px;
    margin-top: 20px;
    width: 100%;
    text-align: center;
}

nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: space-between;
}

nav li {
    text-align: center;
}

nav a {
    color: #fff;
    text-decoration: none;
}

section {
  margin-bottom: 20px; /* Add space between sections */
}

h2 {
  margin-bottom: 10px; /* Add space below headings */
}
footer{
    max-width: 100%;
    margin: 0 auto;
    display: flex;
    text-align: center;
    background-color: #092044;
    color: white;
    font-size: 12px;
    position: fixed;
    bottom: 0;
    width: 100%;
}
.user-actions {
    display: flex;
    align-items: center;
}

.login-btn {
    margin-right: 10px;
    background-color: #092044;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
}

.login-btn:hover {
    background-color: #063366;
}
.slider{
    width: auto;
    height: 300px;
    position: relative;
    overflow: hidden;
}
.slider .list{
    position: absolute;
    width: max-content;
    height: 100%;
    left: 0;
    top: 0;
    display: flex;
    transition: 1s;
}
.slider .list img{
    width: auto;
    max-width: auto;
    height: 100%;
    object-fit: cover;
}
.slider .buttons{
    position: absolute;
    top: 45%;
    left: 5%;
    width: 90%;
    display: flex;
    justify-content: space-between;
}
.slider .buttons button{
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background-color: #fff5;
    color: #fff;
    border: none;
    font-family: monospace;
    font-weight: bold;
}
.slider .dots{
    position: absolute;
    bottom: 10px;
    left: 0;
    color: #fff;
    width: 100%;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
}
.slider .dots li{
    list-style: none;
    width: 10px;
    height: 10px;
    background-color: #fff;
    margin: 10px;
    border-radius: 20px;
    transition: 0.5s;
}
.slider .dots li.active{
    width: 30px;
}
@media  screen and (max-width: 100%){
    .slider{
        height: 300px;
    }
}</style>
    </head>
    <body class="font-sans antialiased dark:bg-black dark:text-white/50">
    <header>
    	<div class="container-header">
            <img src="logo_20200823.jpg" alt="utkylui" class="logo">
            <div class="user-actions">
                <a href="<?php echo e(route('login')); ?>" class="login-btn">Login</a>

            <div class="search-bar">
            <input type="text" placeholder="Search">
            </div>
        </div>
        </div>
        <div class="container-nav">
            <nav>
                <ul>
                    <li><a href="patent.html">Patent</a></li>
                    <li><a href="trademark.html">Trademark</a></li>
                    <li><a href="IndustrialForm.html">Industrial Design</a></li>
                    <li><a href="GeographicalForm.html">Geographical Indication</a></li>
                    <li><a href="copyright.html">Copyright</a></li>
                    <li><a href="<?php echo e(route('customerdash')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('welcome')); ?>">About Us</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>
    	<div class="slider">
        <div class="list">
            <div class="item">
                <img src="<?php echo e(asset('slide1.jpg')); ?>" alt="1">
            </div>
            <div class="item">
                <img src="<?php echo e(asset('slide2.jpg')); ?>" alt="2">
            </div>
            <div class="item">
                <img src="<?php echo e(asset('slide3.jpg')); ?>" alt="3">
            </div>
        </div>
        <div class="buttons">
            <button id="prev"><</button>
            <button id="next">></button>
        </div>
        <ul class="dots">
            <li class="active"></li>
            <li></li>
            <li></li>
        </ul>
    </div>
    <div class="container">
            <section class="about-us">
                <h2>About Us</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </section>
        </div>
        <div class="container">
            <section>
                <h2>Vision</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </section>
        </div>
        <div class="container">
            <section>
                <h2>Mission</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </section>
        </div>
</main>
<footer>
        <div class="container">
            <p>&copy; 2024 Your Website Name</p>
        </div>
    </footer>
    </body>
    <script>
let slider = document.querySelector('.slider .list');
let items = document.querySelectorAll('.slider .list .item');
let next = document.getElementById('next');
let prev = document.getElementById('prev');
let dots = document.querySelectorAll('.slider .dots li');

let lengthItems = items.length - 1;
let active = 0;
next.onclick = function(){
    active = active + 1 <= lengthItems ? active + 1 : 0;
    reloadSlider();
}
prev.onclick = function(){
    active = active - 1 >= 0 ? active - 1 : lengthItems;
    reloadSlider();
}
let refreshInterval = setInterval(()=> {next.click()}, 3000);
function reloadSlider(){
    slider.style.left = -items[active].offsetLeft + 'px';
    // 
    let last_active_dot = document.querySelector('.slider .dots li.active');
    last_active_dot.classList.remove('active');
    dots[active].classList.add('active');

    clearInterval(refreshInterval);
    refreshInterval = setInterval(()=> {next.click()}, 3000);
}

dots.forEach((li, key) => {
    li.addEventListener('click', ()=>{
         active = key;
         reloadSlider();
    })
})
window.onresize = function(event) {
    reloadSlider();
};
</script>
</html>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/multi-user/resources/views/welcome.blade.php ENDPATH**/ ?>