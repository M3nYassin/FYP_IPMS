
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
body {
    font-family: sans-serif;
    margin: 0;
    padding: 0;
    background-color: #fff;
}
header {
    background-color: white;
    color: #fff;
}
.container-nav {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #092044;
}
.container-header{
    width: 100%;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.logo {
    width: 200px;
    height: auto;
    margin: 15px;
}
.search-bar {
    margin-left: auto;
    text-align: right;
    border: 2px solid #ccc;
    border-radius: 5px;
}
input[type="text"] {
    padding: 10px;
    width: 80%;
    border: none;
    border-radius: 5px;
}
nav {
    margin-left: 20%;
    margin-right: 20%;
    margin-bottom: 20px;
    margin-top: 20px;
    width: 100%;
    text-align: center;
}
nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: space-between;
}
nav li {
    text-align: center;
}
nav a {
    color: #fff;
    text-decoration: none;
}
section {
  margin-bottom: 20px; /* Add space between sections */
}

h2 {
  margin-bottom: 10px; /* Add space below headings */
}
footer{
    max-width: 100%;
    margin: 0 auto;
    display: flex;
    text-align: center;
    background-color: #092044;
    color: white;
    font-size: 12px;
    position: fixed;
    bottom: 0;
    width: 100%;
}
.user-actions {
    display: flex;
    align-items: center;
}
.login-btn {
    margin-right: 10px;
    background-color: #092044;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
}
.login-btn:hover {
    background-color: #063366;
}
.main-content {
    display: flex;
    justify-content: space-around;
    align-items: center;
    text-align: center;
    width: 100%;
}
.recent {
    flex: 1;
    margin: 0;
	font-size:20px;
}
.recent a, .recent  {
	padding: 15px;
	color:black;
	text-decoration: none;
	font-weight:bold;
	font-size:24px;
}
.activity-window, .track-window, .notify-window {
    margin-left: 20%;
    height: 30vh;
    border-radius: 20%;
    width: 60%;
    border: 2px solid gray; /* Add this line to set the border */
	//box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Shadow */
	background-color: #f2f2f2; /* Light gray background color */
	font-weight:normal;
	font-size:15px;
}
.container {
    max-width: 1000px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    text-align: center;
}
    </style>
</head>
<body>
    <header>
    	<div class="container-header">
            <img src="logo_20200823.jpg" alt="utkylui" class="logo">
            <div class="user-actions">
            <button class="login-btn">Login</button>
            <div class="search-bar">
            <input type="text" placeholder="Search">
            </div>
        </div>
        </div>
        <div class="container-nav">
            <nav>
                <ul>
                    <li><a href="patent.html">Patent</a></li>
                    <li><a href="trademark.html">Trademark</a></li>
                    <li><a href="IndustrialForm.html">Industrial Design</a></li>
                    <li><a href="GeographicalForm.html">Geographical Indication</a></li>
                    <li><a href="copyright.html">Copyright</a></li>
                    <li><a href="{{ route('customerdash') }}">Dashboard</a></li>
                    <li><a href="{{ route('welcome')}}">About Us</a></li>
                </ul>
            </nav>
        </div>
    </header>
	
	
	<div class="main-content">
		<div class="recent">
			<a href="#">Recent Activity</a>
			<div class="activity-window">
				<p>You got a job</p>
				<p>You got a job</p>
				<p>You got a job</p>
				<p>You got a job</p>
			</div>
		</div>
		
		<div class="recent">
			<a href="{{ route('iplist')}}">Track your IP</a>
			<div class="track-window">
				<p>You got a job2</p>
				<p>You got a job</p>
				<p>You got a job</p>
				<p>You got a job</p>
				<p>You got a job</p>
			</div>
		</div>
		
		<div class="recent">
			<a href="{{ route('notification') }}">Notifications</a>
			<div class="notify-window">
				<p>You got a job3</p>
				<p>You got a job</p>
				<p>You got a job</p>
			</div>
		</div>
	</div>
    <footer>
        <div class="container">
            <p>&copy; 2024 Your Website Name</p>
        </div>
    </footer>
</body>
</html>
<a href="/logout">Logout</a>


